import os
import logging
import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

TOKEN = os.getenv("TELEGRAM_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("암호화폐 포지션 분석 봇입니다.\n/position BTCUSDT 처럼 입력해주세요.")

async def position(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if len(context.args) != 1:
        await update.message.reply_text("사용법: /position [코인심볼], 예: /position BTCUSDT")
        return

    symbol = context.args[0].upper()
    await update.message.reply_text(f"{symbol}의 현재 포지션은: 롱 (예시)")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("position", position))

    app.run_polling()
